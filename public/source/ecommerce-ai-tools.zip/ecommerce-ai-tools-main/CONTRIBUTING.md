# Contributing to Nexscope ecommerce guides

Thanks for helping other ecommerce sellers and developers make better decisions with evidence. This repository contains public guides and support resources for hosted Nexscope tools. It does not contain the hosted application's source code.

Participation in this repository is governed by the [Code of Conduct](CODE_OF_CONDUCT.md). Report security concerns privately by following the [security policy](SECURITY.md), not through a public issue or discussion.

## Pick a contribution path

- Ask a tool or REST/MCP integration question in [Discussions Q&A](https://github.com/nexscope-ai/ecommerce-ai-tools/discussions/categories/q-a). Include the goal, the relevant tool or endpoint, what you tried, and what is unclear.
- Propose a workflow in [Discussions Ideas](https://github.com/nexscope-ai/ecommerce-ai-tools/discussions/categories/ideas). Explain who needs it and what result would help them decide what to do next.
- Report a reproducible product or documentation bug with the [Issue forms](https://github.com/nexscope-ai/ecommerce-ai-tools/issues/new/choose). Include steps, expected and actual results, and an error code if available.
- Suggest a correction or case study by opening a pull request against the relevant file under `docs/`. State what changed and link to primary evidence when possible.

Everything committed to this repository is public on GitHub; files under `docs/` are also published on the learning site. Review every new public file and its assets before opening a pull request. Keep internal plans, dashboards, account records, and unpublished drafts outside this repository.

## Evidence for examples and case studies

Use a real input that can be shared, record when and where the run happened, distinguish requested from returned counts, and separate source data from interpretation. Label estimates, missing values, and limitations. Include actual credit usage only when verified in account records; do not promise the number of runs that 1,000 trial credits will cover. State when an example is illustrative rather than a live result.

Do not submit passwords, API keys, access tokens, payment information, personal customer data, or unredacted logs or screenshots. For private account or billing matters, use [private support](mailto:service@nexscope.ai).

The team reviews contributions and may request clarification or edits. A proposal or pull request does not guarantee inclusion.

## Maintainer workflow: rebuild Product Gallery pages

Maintainers can rebuild all approved and published Product Gallery pages from the repository root:

```powershell
.\scripts\rebuild-product-showcase.ps1
```

The script replaces the generated `docs/product-showcase/product` directory, product manifest, and old `_site` output. It fetches the current published product JSON, applies each product's `seoConfig`, renders the product template, rebuilds the sitemap manifest, and runs a complete Jekyll build. Removed or ineligible products are therefore removed from the generated site and sitemap.

The product template applies metadata, Open Graph and Twitter tags, alternate-language links, and Product/WebPage JSON-LD from the safely serialized configuration. Visible badges come only from `seoConfig.tags`; SEO keywords do not become visible badges. Submitted Markdown headings receive stable anchors, and a details table of contents appears when the content contains at least two sections.

## License of contributions

Unless explicitly stated otherwise, contributions accepted into this repository are licensed under the [Apache License 2.0](LICENSE). Only submit material that you have the right to share under those terms, and preserve attribution or third-party license notices when required.
